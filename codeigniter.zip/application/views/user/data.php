<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('user/index'); ?>">
            <div class="sidebar-brand-icon">
                <i class="fas fa-user-tie"></i>
            </div>
            <div class="sidebar-brand-text mx-3">Koperasi Pinrang</div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider">





        <!-- Heading -->
        <div class="sidebar-heading">
            Member
        </div>

        <li class="nav-item active">
            <a class="nav-link" href="<?= base_url('user/data'); ?>">
                <i class="fas fa-fw fa-chart-area"></i>
                <span>Verfikasi Data</span></a>
        </li>


        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('user/pengajuan'); ?>">
                <i class="fas fa-donate"></i>
                <span>Pengajuan Pinjaman</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('user/informasi'); ?>">
                &nbsp;<i class="fas fa-question"></i>
                <span>&nbsp;Informasi</span></a>
        </li>





        <!-- Nav Item - Charts -->

        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

    </ul>
    <!-- End of Sidebar -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">

    </button>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>



                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">

                    <!-- Nav Item - Search Dropdown (Visible Only XS) -->



                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= $user['nama']; ?></span>
                            <img class="img-profile rounded-circle" src="<?= base_url('assets/'); ?>img/undraw_profile.svg">
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="<?= base_url('user/profile'); ?>">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Profile
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>

            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <div class="container" style="margin-top:30px">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <center>
                                    <h3 class="panel-title"><strong>VERFIKIASI DATA</strong></h3>
                                    <hr style="margin-top:10px;margin-bottom:10px;">
                                </center>
                            </div>
                            <?php
                            if (empty($anggota)) {
                            ?>
                                <div class="panel-body">
                                    <?php if ($this->session->flashdata('flash')) : ?>
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <strong>Berhasil</strong> <?= $this->session->flashdata('flash'); ?>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    <?php unset($_SESSION['flash']); ?>
                                    <?php echo form_open_multipart('user/insertdata'); ?>
                                    <div class="form-group">
                                        <input placeholder="Tanggal Pendaftaran" name="tgl_pendaftaran" class="form-control" value="<?php date_default_timezone_set('Asia/Jakarta');
                                                                                                                                    echo date("Y-m-d"); ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="number" name="no_ktp" id="No Ktp" class="form-control " placeholder="No KTP" tabindex="3" required>
                                </div>
                                <div class="form-group">
                                    <input type="number" name="no_induk" id="no induk" class="form-control " placeholder="No Induk Pegawai" tabindex="3" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="nama" id="nama" class="form-control " value="<?= $user['nama'] ?>" tabindex="3" readonly required>
                                </div>
                                <div class="form-group">
                                    <select name="jenis_kel" id="" class="form-control">
                                        <option placeholder="Jenis Kelamin" readonly hidden>Pilih Jenis Kelamin</option>
                                        <option value="laki-laki">Laki Laki</option>
                                        <option value="perempuan">Perempuan</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="gol" id="gol" class="form-control" maxlength="2" placeholder="Golongan" tabindex="4" required>
                                </div>
                                <div class="form-group">
                                    <input type="number" name="umur" id="umur" class="form-control" maxlength="2" placeholder="Umur" tabindex="4" required>
                                </div>
                                <div class="form-group">
                                    <select name="st_pegawai" id="" class="form-control">
                                        <option placeholder="Status Pegawai" hidden>Status Pegawai</option>
                                        <option value="aktif">Aktif</option>
                                        <option value="tidak aktif">Tidak Aktif</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="asal_sklh" id="asal_sklh" class="form-control" maxlength="40" placeholder="Asal Sekolah" tabindex="4" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="alamat" id="alamat" class="form-control" maxlength="40" placeholder="Alamat" tabindex="4" required>
                                </div>
                                <div class="form-group">
                                    <input type="number" name="no_hp" id="no_hp" class="form-control" maxlength="14" placeholder="No. Handphone" tabindex="4" required>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" id="email" class="form-control" maxlength="40" value="<?= $user['email'] ?>" tabindex="4" readonly required>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="customFile" name="foto_ktp" multiple="">
                                                <label class="custom-file-label" for="customFile">Foto Copy Ktp</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="customFile" name="tb_transfer" multiple="">
                                                <label class="custom-file-label" for="customFile">Tanda Bukti Pembayaran</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <center><button id="submit" type="submit" class="btn btn-success">Verfikasi</button></center>

                                <hr style="margin-top:10px;margin-bottom:10px;">
                                <?php echo form_close(); ?>
                                <?php
                            } else {
                                if ($anggota['status_data'] != 1) { ?>
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Perhatian</strong> Data anda sedang di Verifikasi, Harap menunggu!
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php } elseif ($anggota['status_data'] == 1) { ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Selamat</strong> Verifikasi anda berhasil, Sekarang kamu bisa melakukan pengajuan.
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                            <?php }
                            } ?>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>

        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Koprasi Pinrang 2021</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?= base_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>


<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
</script>

<script>
    const flashdata = $('.flash-data').data('flashdata');
    console.log(flashdata);
</script>



</html>