<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('admin/index'); ?>">
            <div class="sidebar-brand-icon">
                <i class="fas fa-user-tie"></i>
            </div>
            <div class="sidebar-brand-text mx-3">Koperasi Simpan Pinjam</div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider">


        <div class="sidebar-heading">
            Administrator
        </div>

        <!-- Nav Item - Dashboard -->
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('admin/index'); ?>">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('admin/data_member'); ?>">
                <i class="fas fa-fw fa-chart-area"></i>
                <span>Data Simpanan</span></a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('admin/persetujuan'); ?>">
                <i class="fas fa-vote-yea"></i>
                <span>Data Pinjaman</span></a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('admin/data_pengajuan'); ?>">
                <i class="fas fa-vote-yea"></i>
                <span>Data Persetujuan</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('admin/data'); ?>">
                <i class="fas fa-vote-yea"></i>
                <span>Data Verfikasi Pendaftaran</span></a>
        </li>