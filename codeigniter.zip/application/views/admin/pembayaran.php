<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="container-fluid">
        <div class="row">
            <div class="col">

                <h3 class="my-2">Angsuran <?php echo $detailSimpanan->id_anggota; ?></h3>

                <form action="<?= base_url() ?>Admin/bayar_angsuran" method="POST">
                    <input type="hidden" name="tgl_bayar" class="form-control" id="tgl_bayar" value="<?php date_default_timezone_set('Asia/Jakarta');
                                                                                                        echo date("Y-m-d"); ?>" readonly>
                    <input type="hidden" name="kode_pembayaran" id="kode_pembayaran" value="<?= $kode_pembayaran ?>">
                    <div class="form-group row">
                        <label for="nama_simpanan" class="col-sm-2 col-form-label">Tanggal Angsuran</label>
                        <div class="col-sm-10">
                            <input type="text" name="tgl_angsuran" class="form-control" id="tgl_angsuran" value="<?= $detailSimpanan->tgl_persetujuan; ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="nama_simpanan" class="col-sm-2 col-form-label">No Anggota</label>
                        <div class="col-sm-10">
                            <input type="text" name="id_anggota" class="form-control" id="id_anggota" value="<?= $detailSimpanan->id_anggota; ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="besar_simpanan" class="col-sm-2 col-form-label">Nama</label>
                        <div class="col-sm-10">
                            <input type="text" name="nama_angota" class="form-control" id="nama" value="<?= $detailSimpanan->nama_anggota; ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tgl_entri" class="col-sm-2 col-form-label">Bunga Pinjaman</label>
                        <div class="col-sm-10">
                            <input type="text" name="bungaPinjaman" class="form-control" id="bungaPinjaman" value="<?= $detailSimpanan->bunga ?>%" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tgl_entri" class="col-sm-2 col-form-label">Jumlah Pengajuan</label>
                        <div class="col-sm-10">
                            <input type="text" name="jmlPengajuan" class="form-control" id="jmlPengajuan" value="<?= $jml_pengajuan; ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tgl_entri" class="col-sm-2 col-form-label">Jumlah Pembayaran</label>
                        <div class="col-sm-10">
                            <input type="number" name="jumlah_pembayaran" class="form-control" id="jumlah_pembayaran" value="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tgl_entri" class="col-sm-2 col-form-label">Sisa Pembayaran</label>
                        <div class="col-sm-10">
                            <input type="number" name="sisa_pembayaran" class="form-control" id="sisa_pembayaran" readonly value="<?= $jml_pengajuan; ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tgl_entri" class="col-sm-2 col-form-label">Jangka Waktu Pinjaman</label>
                        <div class="col-sm-10">
                            <input type="text" name="jangkaWaktu" class="form-control" id="nama" value="<?= $detailSimpanan->jnk_waktu; ?> Bulan" readonly>
                        </div>
                    </div>

                    <div class=" form-group row">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Ubah Data</button>
                            <a href="<?= base_url() ?>Admin/angsuran/<?= $detailSimpanan->id_anggota ?>" class="btn btn-danger">Kembali</a>
                        </div>
                    </div>

                    <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
                    <script type="text/javascript">
                        $(document).ready(function() {
                            $("#jumlah_pembayaran").keyup(function() {
                                var jmlBayar = $("#jumlah_pembayaran").val();
                                var jmlPengajuan = $("#jmlPengajuan").val();

                                if (parseInt(jmlBayar) > parseInt(jmlPengajuan)) {
                                    $("#jumlah_pembayaran").val('');
                                    $("#sisa_pembayaran").val(jmlPengajuan);
                                } else {
                                    var sisaBayar = parseInt(jmlPengajuan) - parseInt(jmlBayar);
                                    $("#sisa_pembayaran").val(sisaBayar);
                                }


                            });
                        });
                    </script>
                </form>
            </div>

        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Koprasi Simpan Pinjam <?= date('Y'); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?= base_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>



</html>