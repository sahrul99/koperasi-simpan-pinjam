<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <h3 class="my-2"><i class="fas fa-paste"></i> Data Pengambilan Uang "<?php echo $pengambilan['nama_anggota']; ?>"</h3>

                <table class="table table-bordered table-hover mt-3">
                    <thead>
                        <tr>
                            <thead class="bg-primary text-white">
                                <th scope="col">No</th>
                                <th scope="col">Kode Anggota</th>
                                <th scope="col">Nama Anggota</th>
                                <th scope="col">Besar Ambil</th>
                                <th scope="col">Tanggal Ambil</th>
                                <th scope="col" class="text-center">Aksi</th>
                            </thead>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>

                        <tr>
                            <th scope="row"><?php echo $i++; ?></th>
                            <td><?php echo $pengambilan['kode_anggota']; ?></td>
                            <td><?php echo $pengambilan['nama_anggota']; ?></td>
                            <td>Rp. <?php echo number_format($pengambilan['besar_ambil'], 0, ',', '.'); ?></td>
                            <td><?php echo $pengambilan['tgl_ambil']; ?></td>
                            <td align="center">
                                <a href="/koperasi/pengambilanuang/<?php echo $pengambilan['kode_ambil']; ?>" class="btn btn-info btn-sm"><i class="fas fa-dollar-sign"></i> Ambil Uang</a>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Koprasi Simpan Pinjam <?= date('Y'); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?= base_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>



</html>