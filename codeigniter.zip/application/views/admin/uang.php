<!-- Begin Page Content -->
<div class="container-fluid">
    <h3 class="my-2 mb-3"><i class="fas fa-history"></i> Riwayat Pengambilan</h3>
    <!-- Page Heading -->
    <a href="<?= base_url('') ?>Admin/uang/<?= $id_anggota ?>" class="btn btn-sm btn-success btn-hapus"><i class="fas fa-money-bill-wave-alt" aria-hidden="true"></i> Ambil Uang</i></a>
    <a href="<?= base_url('') ?>Admin/data_simpanan/<?= $id_anggota ?>" class="btn btn-sm btn-danger btn-hapus"><i class="fas fa-undo-alt" aria-hidden="true"></i> Kembali</i></a>
    <table class="table table-bordered table-hover center" id="tb_dataMember">
        <?php if ($this->session->flashdata('pengambilanUang')) : ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Berhasil</strong> <?= $this->session->flashdata('pengambilanUang'); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php unset($_SESSION['pengambilanUang']);
        endif; ?>
        <thead>
            <tr>
                <thead class="bg-primary text-white">
                    <th scope="col">No</th>
                    <th scope="col">No Anggota</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Tanggal Pengambilan</th>
                    <th scope="col">Total Uang</th>
                    <th scope="col">Besar Pengambilan</th>
                    <th scope="col">Sisa Uang</th>
                </thead>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($detailSimpanan as $row) { ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row->id_anggota ?></td>
                    <td><?= $row->nama ?></td>
                    <td><?= $row->tgl_ambil ?></td>
                    <td>Rp. <?php echo number_format($row->sukarela, 0, ',', '.'); ?></td>
                    <td>Rp. <?php echo number_format($row->besar_ambil, 0, ',', '.'); ?></td>
                    <td>Rp. <?php echo number_format($row->sukarela - $row->besar_ambil, 0, ',', '.'); ?></td>
                </tr>
            <?php } ?>


        </tbody>
    </table>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Koprasi Simpan Pinjam <?= date('Y'); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?= base_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>



</html>