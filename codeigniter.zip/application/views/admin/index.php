<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="jumbotron jumbotron-fluid text-center">
        <h1 class="display-2">Hai, Selamat Datang Administrator!</h1>
        <p class="lead"></p>
        <hr class="my-4">
        <img src="https://kopmafeuii.com/wp-content/uploads/2017/06/LAMBANG-KOPERASI.png" alt="logo-koperasi" style="width: 300px; height: 300px;">
        <p>Apakah terdapat anggota yang akan melakukan Transaksi?? Jika iya anda bisa klik button berikut!</p>
        <a class="btn btn-primary btn-lg" href="<?= base_url('admin/data_member'); ?>" role="button">Transaksi Simpan</a>
        <a class="btn btn-success btn-lg" href="<?= base_url('admin/persetujuan'); ?>" role="button">Transaksi Pinjam</a>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Koprasi Simpan Pinjam <?= date('Y'); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?= base_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>



</html>