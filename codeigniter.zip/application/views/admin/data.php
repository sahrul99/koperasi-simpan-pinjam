<!-- Begin Page Content -->
<div class="container-fluid">
    <h3 class="my-2 mb-3"><i class="fas fa-landmark"></i> Data Koprasi</h3>
    <!-- Page Heading -->
    <table class="table table-bordered table-hover center" id="tb_dataMember">
        <?php if ($this->session->flashdata('cekdata')) : ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Berhasil</strong> <?= $this->session->flashdata('cekdata'); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php unset($_SESSION['cekdata']);
        endif; ?>
        <thead class="bg-primary text-white">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Tanggal Pendaftaran</th>
                <th scope="col">No Anggota</th>
                <th scope="col">No Ktp</th>
                <th scope="col">No Induk Pegawai</th>
                <th scope="col">Nama</th>
                <th scope="col">Status Pegawai</th>
                <th scope="col">No Telp</th>
                <th scope="col">Email</th>
                <th scope="col">Status Data</th>
                <th scope="col">Detail Data</th>
                <th scope="col">Verfikasi Data</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php foreach ($data as $a) { ?>
                <tr>
                    <th scope="row"><?php echo $i++; ?></th>
                    <td><?= $a['tgl_pendaftaran']; ?></td>
                    <td><?php echo $a['id_anggota']; ?></td>
                    <td><?php echo $a['no_ktp']; ?></td>
                    <td><?php echo $a['no_induk']; ?></td>
                    <td><?php echo $a['nama']; ?></td>
                    <td class="text-center"><?php
                                            if ($a['st_pegawai'] == "aktif") { ?>
                            <span class="badge badge-success ">Aktif</span>
                        <?php } else { ?>
                            <span class="badge badge-danger ">Belum Aktif</span>
                        <?php } ?>
                    </td>
                    <td><?php echo $a['no_hp']; ?></td>
                    <td><?php echo $a['email']; ?></td>
                    <td>
                        <?php
                        if ($a['status_data'] == 0) { ?>
                            <span class="badge badge-danger">Belum Diverifikasi</span>
                        <?php } else { ?>
                            <span class="badge badge-success">Sudah Diverifikasi</span>
                        <?php } ?>
                    </td>
                    <td>
                        <a href="<?= base_url() ?>Admin/detail_datamember/<?= $a['id_data']; ?>" class="btn btn-primary btn-sm center"><i class="fas fa-detail">DETAILS</i></a>

                    </td>
                    <td>
                        <?php
                        if ($a['status_data'] == 0) { ?>
                            <a href="<?= base_url() ?>Admin/verifikasi_data/<?= $a['id_data']; ?>" onclick="return confirm('Yakin ingin memverifikasi data ini?');" class="btn btn-info btn-sm center"><i class="fas fa-detail">VERFIKASI</i></a>
                        <?php } else { ?>
                            <a href="javascript:void(0);" class="btn btn-dark btn-sm center disabled"><i class="fas fa-detail">VERFIKASI</i></a>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    <!-- Modal -->

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Koprasi Simpan Pinjam <?= date('Y'); ?></span>
        </div>
    </div>
</footer>



</html>