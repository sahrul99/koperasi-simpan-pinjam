<style>
    @media print {
        sidebar {
            display: none;
        }

        a {
            display: none;
        }

        .btn {
            display: none;
        }

        .navbar-nav {
            display: none;
        }
    }
</style>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 align="center">Detail Data</h1>
    <a href="#" onclick="window.print();" class="btn btn-primary"><i class="fa fa-print"> Print</i></a>
    <a href="<?= base_url('admin/data'); ?>" class="btn btn-danger"><i></i>Kembali</a>
    <table class="table" align="center">
        <tr>
            <th>Tanggal Pendaftaran</th>
            <td><?php echo $detail->tgl_pendaftaran; ?></td>
        <tr>
            <th>No Anggota</th>
            <td><?php echo $detail->id_anggota; ?></td>
        </tr>
        <tr>
            <th>No Ktp</th>
            <td><?php echo $detail->no_ktp; ?></td>
        </tr>
        <th>No Induk Pegawai</th>
        <td><?php echo $detail->no_induk; ?></td>
        </tr>
        <tr>
            <th>Nama</th>
            <td><?php echo $detail->nama; ?></td>
        </tr>
        <tr>
            <th>Jenis Kelamin</th>
            <td><?php echo $detail->jenis_kel; ?></td>
        </tr>
        <tr>
            <th>Golongan</th>
            <td><?php echo $detail->gol; ?></td>
        </tr>
        <tr>
            <th>Umur</th>
            <td><?php echo $detail->umur; ?></td>
        </tr>
        <tr>
            <th>Status Pegawai</th>
            <td><?php echo $detail->st_pegawai; ?></td>
        </tr>
        <tr>
            <th>Alamat</th>
            <td><?php echo $detail->alamat; ?></td>
        </tr>
        <tr>
            <th>Asal Sekolah</th>
            <td><?php echo $detail->asal_sklh; ?></td>
        </tr>
        <tr>
            <th>No Handphone</th>
            <td><?php echo $detail->no_hp; ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?php echo $detail->email; ?></td>
        </tr>
    </table>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Koprasi Simpan Pinjam <?= date('Y'); ?></span>
        </div>
    </div>
</footer>

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?= base_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>