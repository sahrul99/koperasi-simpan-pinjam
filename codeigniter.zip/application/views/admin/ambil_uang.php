<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <h3 class="my-2 mb-3"><i class="fas fa-hand-holding-usd"></i> Pengambilan Uang Simpanan</h3>

                <form action="<?= base_url('') ?>admin/pengambilan_uang" method="POST">

                    <div class="col-sm-10">
                        <input type="hidden" name="kode_ambil" class="form-control" id="kode_ambil" value="<?php echo $kode_ambil; ?>" readonly>
                    </div>
                    <div class="col-sm-10">
                        <input type="hidden" name="id_anggota" class="form-control" id="id_anggota" value="<?php echo $pengambilan->id_anggota; ?>" readonly>
                    </div>
                    <div class="col-sm-10">
                        <input type="hidden" name="nama" class="form-control" id="nama" value="<?php echo $pengambilan->nama; ?>" readonly>
                    </div>
                    <div class="col-sm-10">
                        <input type="hidden" name="wajib" class="form-control" id="wajib" value="<?php echo $pengambilan->spn_wajib; ?>" readonly>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">Total Simpanan</label>
                        <div class="col-sm-10">
                            <input type="text" name="simpanan" class="form-control" id="simpanan" value="<?php echo $pengambilan->spn_sukarela; ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">Ambil Uang</label>
                        <div class="col-sm-10">
                            <input type="text" name="besar_ambil" class="form-control" id="besar_ambil">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">Sisa Uang</label>
                        <div class="col-sm-10">
                            <input type="text" name="sisa_uang" class="form-control" id="sukarela" value="" readonly>
                        </div>
                    </div>
                    <div class="col-sm-10">
                        <input type="hidden" name="tgl_ambil" class="form-control" id="tgl_ambil" value="<?php date_default_timezone_set('Asia/Jakarta');
                                                                                                            echo date("Y-m-d"); ?>" readonly>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> Simpan</button>
                            <a href="<?= base_url('') ?>Admin/ambil_uang/<?php echo $pengambilan->id_anggota; ?>" class="btn btn-danger"><i class="fas fa-backspace"></i> Kembali</a>
                        </div>
                    </div>

                    <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
                    <script type="text/javascript">
                        $(document).ready(function() {
                            $("#simpanan, #besar_ambil").keyup(function() {
                                var simpanan = $("#simpanan").val();
                                var besar_ambil = $("#besar_ambil").val();

                                var total = parseInt(simpanan) - parseInt(besar_ambil);
                                $("#sukarela").val(total);
                            });
                        });
                    </script>
                </form>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Koprasi Pinrang <?= date('Y'); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?= base_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>



</html>