<!-- Begin Page Content -->
<div class="container-fluid">
    <h3 class="my-2 mb-3"><i class="fas fa-money-bill-wave"></i> Simpanan</h3>
    <!-- Page Heading -->
    <table class="table table-bordered table-hover center" id="tb_dataMember">
        <?php if ($this->session->flashdata('detailcek')) : ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Berhasil</strong> <?= $this->session->flashdata('detailcek'); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php unset($_SESSION['detailcek']);
        endif; ?>
        <thead>
            <tr>
                <thead class="bg-primary text-white">
                    <th scope="col">No</th>
                    <th scope="col">No Anggota</th>
                    <th scope="col">No Induk Pegawai</th>
                    <th scope="col">No Ktp</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Email</th>
                    <th scope="col">Jumlah Pokok</th>
                    <th colspan="3" class="text-center">AKSI</th>
                </thead>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach ($datamember as $s) { ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $s['id_anggota']; ?></td>
                    <td><?php echo $s['no_induk']; ?></td>
                    <td><?php echo $s['no_ktp']; ?></td>
                    <td><?php echo $s['nama']; ?></td>
                    <td><?php echo $s['alamat']; ?></td>
                    <td><?php echo $s['email']; ?></td>
                    <td>Rp. <?php echo number_format($s['jml_pokok'], 0, ',', '.'); ?></td>
                    <td><a href="<?= base_url() ?>Admin/edit_datamember/<?= $s['id_anggota']; ?>" class="btn btn-primary">VERFIKASI</a></td>
                    <td>
                        <?php
                        if ($s['jml_pokok'] == 0) { ?>
                            <a href="javascript:void(0)" class="btn btn-secondary">SIMPAN UANG</a>
                        <?php } else { ?>
                            <a href="<?= base_url() ?>Admin/data_simpanan/<?= $s['id_anggota']; ?>" class="btn btn-danger">SIMPAN UANG</a>
                        <?php }
                        ?>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Koprasi Simpan Pinjam <?= date('Y'); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?= base_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>



</html>