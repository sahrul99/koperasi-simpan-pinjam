<?php
class Verfikasi_data extends CI_Model
{
    protected $table = 'tb_pengajuan';

    function inputdata($data)
    {
        $this->db->insert('tb_data', $data);
        return true;
    }
    function pengajuandata($data)
    {
        return $this->db->table($this->table)->insert($data);
        return true;
    }
}
