<?php
class Pengajuan extends CI_Model
{
    function pengajuan()
    {
        $data = $this->db->query("SELECT * FROM tb_pengajuan");
        return $data->result_array();

        $data = $this->db->get_where("tb_pengajuan", array('no_anggota'));
    }

    function persetujuan()
    {
        $data = $this->db->query("SELECT * FROM tb_persetujuan");
        return $data->result_array();
    }

    function get_pengajuan($id)
    {
        $query = $this->db->get_where('tb_pengajuan', array('id_pengajuan' => $id))->row();
        return $query;
    }

    function get_anggota($id)
    {
        $query = $this->db->get_where('tb_anggota', array('id_anggota' => $id))->row();
        return $query;
    }

    function hapusdatapengajuan($id)
    {
        $this->db->where('id_anggota', $id);
        $this->db->delete('tb_pengajuan');
    }
}
