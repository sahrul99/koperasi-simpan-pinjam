<?php defined('BASEPATH') or exit('No direct script access allowed');
class Datakoprasi extends CI_Model
{
    protected $table = 'tb_data';

    function show()
    {
        $data = $this->db->query("SELECT * FROM tb_data");
        return $data->result_array();
    }
    function hapus_data($id)
    {
        $this->db->where('id_data', $id);
        $this->db->delete('tb_data');
    }
    public function detail_data($id)
    {
        $query = $this->db->get_where('tb_data', array('id_data' => $id))->row();
        return $query;
    }
    public function data_simpanan($id)
    {
        $query = $this->db->get_where('tb_simpanan', array('id_anggota' => $id))->row();
        return $query;
    }
    public function spn_sukarela($id)
    {
        $query = $this->db->get_where('tb_simpanan', array('id_anggota' => $id))->row();
        return $query;
    }
    public function spn_wajib($id)
    {
        $query = $this->db->get_where('tb_simpanan', array('id_anggota' => $id))->row();
        return $query;
    }
    public function ambil_uang($id)
    {
        $query = $this->db->get_where('tb_simpanan', array('id_anggota' => $id))->row();
        return $query;
    }
    public function data_uang($id)
    {
        $query = $this->db->query("SELECT * FROM tb_pengambilan WHERE id_anggota = '$id'")->result();
        return $query;
    }

    public function kode_ambil()
    {
        $query = $this->db->count_all('tb_pengambilan');
        return $query;
    }
    public function angsuran($id)
    {
        $query = $this->db->get_where('tb_persetujuan', array('id_anggota' => $id))->row();
        return $query;
    }
    public function data_angsuran($id)
    {
        $query = $this->db->query("SELECT * FROM tb_pembayaran WHERE id_anggota = '$id'")->result();
        return $query;
    }
    public function kode_pembayaran()
    {
        $query = $this->db->count_all('tb_pembayaran');
        return $query;
    }
}
