<?php defined('BASEPATH') or exit('No direct script access allowed');
class AnggotaModel extends CI_Model
{
    function datamember()
    {
        $data = $this->db->query("SELECT * FROM tb_anggota");
        return $data->result_array();
    }
    public function edit_datamember($id)
    {
        $query = $this->db->get_where('tb_anggota', array('id_anggota' => $id))->row();
        return $query;
    }
}
