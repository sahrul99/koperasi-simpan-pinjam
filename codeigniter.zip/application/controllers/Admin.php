<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        ceklogin();
        $this->load->helper('url');
        $this->load->model('Datakoprasi');
        $this->load->model('Pengajuan');
        $this->load->model('AnggotaModel');
    }

    public function index()
    {

        $data['title'] = 'ADMINISTRATOR';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/index', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }

    public function data()
    {
        $data['title'] = 'ADMINISTRATOR';
        $data['data'] = $this->Datakoprasi->show();
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/data', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function data_member()
    {
        $data['title'] = 'Simpanan';
        $data['datamember'] = $this->AnggotaModel->datamember();
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/data_member', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }

    public function data_pengajuan()
    {
        $data['title'] = 'ADMINISTRATOR';
        $data['data'] = $this->Pengajuan->pengajuan();
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/pengajuan', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function persetujuan()
    {
        $data['title'] = 'ADMINISTRATOR';
        $data['data'] = $this->Pengajuan->persetujuan();
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/persetujuan', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function pinjaman()
    {
        $data['title'] = 'ADMINISTRATOR';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/pinjaman', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function detail_datamember($id)
    {
        $detail = $this->Datakoprasi->detail_data($id);
        $data['detail'] = $detail;
        $data['title'] = 'ADMINISTRATOR';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/detail_datamember', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function data_simpanan($id = null)
    {
        if (empty($id)) {
            redirect('admin/data_member');
        }
        $data['title'] = 'ADMINISTRATOR';
        $detailSimpanan = $this->Datakoprasi->data_simpanan($id);
        $data['detailSimpanan'] = $detailSimpanan;
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/data_simpanan', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function edit_datamember($id = null)
    {
        if (empty($id)) {
            $dataMember = [
                'id_anggota' => $this->input->post('idData'),
                'nama'  => $this->input->post('nama'),
                'alamat' => $this->input->post('alamat'),
                'spn_pokok' => $this->input->post('jml_pokok'),
                'spn_wajib' => '50000',
                'spn_sukarela' => '0'
            ];

            $this->db->set('jml_pokok', $dataMember['spn_pokok']);
            $this->db->where('id_anggota', $dataMember['id_anggota']);
            if ($this->db->update('tb_anggota')) {
                if ($this->db->insert('tb_simpanan', $dataMember)) {
                    $this->session->set_flashdata('detailcek', 'Jumlah Pokok ' . $dataMember['id_anggota'] . ' Berhasil diubah!');
                    redirect('admin/data_member');
                }
            }
        } else {
            $data['title'] = 'ADMINISTRATOR';
            $detailmember =  $this->AnggotaModel->edit_datamember($id);
            $data['detailmember'] = $detailmember;
            $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar');
            $this->load->view('admin/topbar');
            $this->load->view('admin/edit_datamember', $data);
            $this->load->view('admin/logout');
            $this->load->view('admin/footer');

            $data = [
                'no_induk' => $detailmember->no_induk,
                'no_ktp' => $detailmember->no_ktp,
                'nama' => $detailmember->nama,
                'alamat' => $detailmember->alamat,
                'email' => $detailmember->email,
                'jml_pokok' => $detailmember->jml_pokok
            ];
            $this->db->where('id_anggota', $id);
            $this->db->update('tb_anggota', $data);
        }
    }

    public function spn_sukarela($id)
    {
        $data['title'] = 'ADMINISTRATOR';
        $dataspn = $this->Datakoprasi->spn_sukarela($id);
        $data['dataspn'] = $dataspn;
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/spn_sukarela', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function edit_spn_sukarela()
    {
        $dataMember = [
            'id_anggota' => $this->input->post('id_anggota'),
            'nama_anggota'  => $this->input->post('nama_anggota'),
            'alamat' => $this->input->post('alamat'),
            'spn_sukarela' => $this->input->post('spn_sukarela')
        ];

        $this->db->set('spn_sukarela', $dataMember['spn_sukarela']);
        $this->db->where('id_anggota', $dataMember['id_anggota']);

        if ($this->db->update('tb_simpanan')) {
            $this->session->set_flashdata('spnCheck', 'Simpanan Sukarela ' . $dataMember['id_anggota'] . ' Berhasil diubah!');
            redirect('admin/data_simpanan/' . $dataMember['id_anggota']);
        }
    }
    public function ambil_uang($id)
    {
        $data['title'] = 'ADMINISTRATOR';
        $dataspn = $this->Datakoprasi->data_uang($id);
        $data['detailSimpanan'] = $dataspn;
        $data['id_anggota'] = $id;
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/uang', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function uang($id)
    {
        $data['title'] = 'ADMINISTRATOR';
        $kodeAmbil = $this->Datakoprasi->kode_ambil();
        $setKodeAmbil = sprintf('A%04d', $kodeAmbil + 1);
        $data['kode_ambil'] = $setKodeAmbil;

        $dataspn = $this->Datakoprasi->ambil_uang($id);
        $data['pengambilan'] = $dataspn;

        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/ambil_uang', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function pengambilan_uang()
    {
        $ambilUang = [
            'kode_ambil' => $this->input->post('kode_ambil'),
            'id_anggota'  => $this->input->post('id_anggota'),
            'nama' => $this->input->post('nama'),
            'wajib' => $this->input->post('wajib'),
            'sukarela' => $this->input->post('simpanan'),
            'besar_ambil' => $this->input->post('besar_ambil'),
            'tgl_ambil' => $this->input->post('tgl_ambil'),
        ];

        $this->db->set('spn_sukarela', $this->input->post('sisa_uang'));
        $this->db->where('id_anggota', $ambilUang['id_anggota']);

        if ($this->db->update('tb_simpanan')) {
            if ($this->db->insert('tb_pengambilan', $ambilUang)) {
                $this->session->set_flashdata('pengambilanUang', 'Sisa Uang ' . $ambilUang['id_anggota'] . ' Berhasil Di Tarik!');
                redirect('admin/ambil_uang/' . $ambilUang['id_anggota']);
            }
        }
    }
    public function angsuran($id)
    {
        $data['title'] = 'ADMINISTRATOR';
        $dataspn = $this->Datakoprasi->data_angsuran($id);
        $data['detailSimpanan'] = $dataspn;
        $data['id_anggota'] = $id;
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/angsuran', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function bayar($id)
    {
        $data['title'] = 'ADMINISTRATOR';

        $kodeBayar = $this->Datakoprasi->kode_pembayaran();
        $setKodeBayar = sprintf('A%04d', $kodeBayar + 1);
        $data['kode_pembayaran'] = $setKodeBayar;

        $dataspn = $this->Datakoprasi->angsuran($id);
        $data['detailSimpanan'] = $dataspn;

        $totalByr = $dataspn->jml_pengajuan;
        $totalBunga = $dataspn->bunga;
        $jnkWaktu   = $dataspn->jnk_waktu;
        $data['jml_pengajuan'] = $totalByr + ($totalByr * $totalBunga * $jnkWaktu) / 100;

        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/pembayaran', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }
    public function bayar_angsuran()
    {
        $ambilUang = [
            'id_pembayaran' => $this->input->post('kode_pembayaran'),
            'id_anggota'  => $this->input->post('id_anggota'),
            'nama' => $this->input->post('nama_angota'),
            'tgl_pengajuan' => $this->input->post('tgl_angsuran'),
            'tgl_bayar' => $this->input->post('tgl_bayar'),
            'jml_pinjaman' => $this->input->post('jmlPengajuan'),
            'jml_pembayaran' => $this->input->post('jumlah_pembayaran'),
            'sisa_pembayaran' => $this->input->post('sisa_pembayaran')
        ];

        if ($this->db->insert('tb_pembayaran', $ambilUang)) {
            $this->session->set_flashdata('pembayaran', 'Pembayaran pinjaman ' . $ambilUang['nama'] . ' Berhasil di lakuukan!');
            redirect('admin/angsuran/' . $ambilUang['id_anggota']);
        }
    }
    public function spn_wajib($id)
    {
        $data['title'] = 'ADMINISTRATOR';
        $dataspn = $this->Datakoprasi->spn_wajib($id);
        $data['dataspn'] = $dataspn;
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar');
        $this->load->view('admin/spn_wajib', $data);
        $this->load->view('admin/logout');
        $this->load->view('admin/footer');
    }



    public function hapusdata($id)
    {
        $this->Datakoprasi->hapus_data($id);
        $this->session->set_flashdata('pesan', 'Data Berhasil Di Hapus');
        redirect('admin/data');
    }
    public function hapuspengajuan($id)
    {
        $this->Pengajuan->hapusdatapengajuan($id);
        $this->session->set_flashdata('cek', 'Data Berhasil Di Hapus');
        redirect('admin/data_pengajuan');
    }
    public function verifikasi_data($id)
    {
        $this->load->helper('email');
        $this->load->library(array("email"));
        $this->email->set_mailtype('html');

        $detail = $this->Datakoprasi->detail_data($id);

        $countData = $this->db->query("SELECT * FROM tb_anggota");
        $id_anggota = 'ANGGOTA' . $countData->num_rows() + 1;

        $data = [
            'id_anggota' => $id_anggota,
            'id_data' => $id,
            'no_induk' => $detail->no_induk,
            'no_ktp' => $detail->no_ktp,
            'nama' => $detail->nama,
            'alamat' => $detail->alamat,
            'email' => $detail->email,
            'jml_pokok' => ''
        ];

        if ($this->db->insert('tb_anggota', $data)) {

            // $configMail = array('mailtype' => 'html', 'charset' => 'utf-8', 'priority' => '1');
            // $this->email->intialize($configMail);
            // $this->email->from('info@koperasipinrang.com', 'Koperasi Pinrang');
            // $this->email->to($detail->email);
            // $this->email->subject('Verifikasi Berhasil');
            // $this->email->message('Hallo ' . $detail->nama . ' Data kamu berhasil diverifikasi');
            // $this->email->send();

            $this->db->query("UPDATE tb_data SET id_anggota='$id_anggota', status_data='1' WHERE id_data='$id'");
            $this->session->set_flashdata('cekdata', 'data berhasil di verfikasi');
            redirect('admin/data');
        }
    }

    public function verifikasi_persetujuan($id)
    {
        $data['title'] = 'Persetujuan';
        $detailmember   =  $this->Pengajuan->get_pengajuan($id);
        $detailAnggota  =  $this->Pengajuan->get_anggota($detailmember->id_anggota);
        date_default_timezone_set('Asia/Jakarta');

        $bungaPinjaman = 2;
        $jangkaPinjaman = 1;
        $hitungTotal = $detailmember->jml_pengajuan + ($detailmember->jml_pengajuan * $bungaPinjaman / 100 * $jangkaPinjaman);

        $data = [
            'id_pengajuan' => $id,
            'id_anggota' => $detailmember->id_anggota,
            'tgl_persetujuan' => date("Y-m-d"),
            'nama_anggota' => $detailAnggota->nama,
            'jml_pengajuan' => $detailmember->jml_pengajuan,
            'keperluan' => $detailmember->keperluan,
            'bunga' => $bungaPinjaman,
            'jnk_waktu' => $jangkaPinjaman,
            'jml_pembayaran' => $hitungTotal
        ];

        $pengajuanUpdate = [
            'status_data' => 1
        ];

        if ($this->db->insert('tb_persetujuan', $data)) {
            $this->db->where('id_pengajuan', $id);
            if ($this->db->update('tb_pengajuan', $pengajuanUpdate)) {
                $this->session->set_flashdata('persetujuan', 'Pinjaman berhasil disetujui.');
                redirect('admin/data_pengajuan');
            }
        }

        // $this->db->where('id_anggota', $id);
        // $this->db->update('tb_anggota', $data);
    }
}
