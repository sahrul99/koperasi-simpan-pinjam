<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $data['title'] = 'Login Koprasi Pinrang';
            $this->load->view('auth/login');
            $this->load->view('templates/auth_header', $data);
            $this->load->view('templates/auth_footer');
        } else {
            // validasi sukses
            $this->login();
        }
    }
    // validasi jika user nya lolos
    private function login()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $user = $this->db->get_where('tb_user', ['email' => $email])->row_array();
        //    jika user nya ada di dalama database
        if ($user) {
            // jika user nya aktif
            if ($user['is_aktif'] == 1) {
                // cek validasi password
                if (password_verify($password, $user['password'])) {
                    $data = [
                        'email' => $user['email'],
                        'tipe_id' => $user['tipe_id']
                    ];
                    $this->session->set_userdata($data);
                    if ($user['tipe_id'] == 1) {
                        redirect('admin');
                    } else {
                        redirect('user');
                    }
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Your Password Is Wrong Please Try Again</div>');
                    redirect('auth');
                    // pesan jika password nya salah
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Your Account Not Register Please Activation First</div>');
                redirect('auth');
                // pesan jika akun nya tidak aktif
            }
        } else {

            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Your Account Not Register Please Register</div>');
            redirect('auth');
            // pesan jika user nya ada
        }
    }


    public function register()
    {
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[tb_user.email]', [

            'is_unique' => 'This Email Has Already Register'
        ]);
        $this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[3]|matches[password2]', [
            'matches' => 'Password Not Matches!',
            'min_length' => 'Password To Short'
        ]);
        $this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]');


        if ($this->form_validation->run() == false) {
            $data['title'] = 'Registrasi Koprasi Pinrang';
            $this->load->view('auth/register');
            $this->load->view('templates/auth_header', $data);
            $this->load->view('templates/auth_footer');
        } else {
            $email = $this->input->post('email', true);
            $data = [
                'nama' => htmlspecialchars($this->input->post('nama', true)),
                'email' => htmlspecialchars($email),
                'image' => 'defalut.jpg',
                'password' => password_hash(
                    $this->input->post('password1', true),
                    PASSWORD_BCRYPT
                ),
                'tipe_id' => 2,
                'is_aktif' => 1,
                'waktu_sesi' => time()
            ];
            // siapkan token
            $token = base64_encode(random_bytes(32));
            $user_token = [
                'email' => $email,
                'token' => $token,
                'date_created' => time()
            ];


            $this->db->insert('tb_user', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your Account Has Been Succesefully Register Please Login</div>');
            redirect('auth');
        }
    }


    public function logout()
    // funtion untuk membersihkan cahce browser dan logout
    {
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('tipe_id');

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your Account Has Been Logout</div>');
        redirect('auth');
    }
    public function blocked()
    {
        $this->load->view('auth/blocked');
    }
}
