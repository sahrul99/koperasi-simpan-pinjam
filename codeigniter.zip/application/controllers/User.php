<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        ceklogin();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        // $this->load->model('Verfikasi_data');
    }


    public function index()
    {
        // menampilkan data user

        $data['title'] = 'Member - Koperasi';
        $this->load->view('user/header', $data);
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('user/index', $data);
        $this->load->view('user/footer');
    }


    public function data()
    {
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->load->library('form_validation');
        $data['title'] = 'Member - Koprasi';
        $this->load->view('user/header', $data);
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $data['anggota'] = $this->db->get_where('tb_data', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('user/data', $data);
        $this->load->view('user/footer');
    }

    public function uploadImage($fileName, $dirName)
    {
        $config['upload_path'] = "./uploads/data-member/" . $dirName . "/";
        $config['allowed_types'] = "jpg|png|jpeg";
        $config['overwrite'] = true;
        $config['max_size'] = 1024; // !MB

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload($fileName)) {
            return false;
        } else {
            return true;
        }
    }

    public function insertdata()
    {

        $data = [
            'tgl_pendaftaran' => date("Y-m-d"),
            'id_anggota' => '',
            'no_induk' => $this->input->post('no_induk'),
            'no_ktp' => $this->input->post('no_ktp'),
            'nama' => $this->input->post('nama'),
            'jenis_kel' => $this->input->post('jenis_kel'),
            'gol' => $this->input->post('gol'),
            'umur' => $this->input->post('umur'),
            'st_pegawai' => $this->input->post('st_pegawai'),
            'alamat' => $this->input->post('alamat'),
            'asal_sklh' => $this->input->post('asal_sklh'),
            'no_hp' => $this->input->post('no_hp'),
            'email' => $this->input->post('email'),
            'foto_ktp' => $this->input->post('no_ktp') . ' - ' . $this->input->post('nama') . '/' . $_FILES['foto_ktp']['name'],
            'tb_transfer' => $this->input->post('no_ktp') . ' - ' . $this->input->post('nama') . '/' . $_FILES['tb_transfer']['name'],
            'status_data' => '0'
        ];

        // Create folder by name
        $folderName = $data['no_ktp'] . " - " . $data['nama'];
        mkdir("./uploads/data-member/$folderName", 0777, TRUE);

        // Get Img

        if ($this->uploadImage('foto_ktp', $folderName)) {
            if ($this->uploadImage('tb_transfer', $folderName)) {
                $this->db->insert('tb_data', $data);
                $this->session->set_flashdata('flash', 'Data Anda Berhasil Di Verfikasi');
                redirect('user/data');
            }
        } else {
            $this->session->set_flashdata('gagal');
            redirect('user/data');
        }
    }
    public function verfikasi_pengajuan()
    {
        $data = [
            'id_anggota' => $this->input->post('id_anggota'),
            'tgl_pengajuan' => $this->input->post('tgl_pengajuan'),
            'jml_pengajuan' => $this->input->post('jml_pengajuan'),
            'keperluan' => $this->input->post('keperluan')
        ];
        $this->db->insert('tb_pengajuan', $data);
        $this->session->set_flashdata('verf', 'Melakukan Pengajuan Silahkan Tunggu Beberapa Saat Lagi');
        redirect('user/pengajuan');
    }
    public function informasi()
    {
        $data['title'] = 'Member - Koperasi';
        $this->load->view('user/header', $data);
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('user/informasi', $data);
        $this->load->view('user/footer');
    }
    public function pengajuan()
    {
        $data['title'] = 'Member - Koprasi';
        $this->load->view('user/header', $data);
        $data['anggota'] = $this->db->get_where('tb_data', ['email' => $this->session->userdata('email')])->row_array();
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('user/pengajuan', $data);
        $this->load->view('user/footer');
    }
}
