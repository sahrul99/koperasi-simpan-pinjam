<?php
class Pengajuan extends CI_Model
{
    function ajuan()
    {
        return $this->db->get($this->tb_pengajuan)->result();
    }
}
